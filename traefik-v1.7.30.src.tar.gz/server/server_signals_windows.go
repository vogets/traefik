// +build windows

package server

func (s *Server) configureSignals() {}

func (s *Server) listenSignals(stop chan bool) {}
