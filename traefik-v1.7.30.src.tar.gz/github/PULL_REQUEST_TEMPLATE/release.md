### What does this PR do?

Prepare release v{{.Version}}.

### Motivation

Create a new release.
